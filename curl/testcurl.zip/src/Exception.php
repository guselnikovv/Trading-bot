<?php

namespace cURL;

class Exception extends \Exception
{
}
